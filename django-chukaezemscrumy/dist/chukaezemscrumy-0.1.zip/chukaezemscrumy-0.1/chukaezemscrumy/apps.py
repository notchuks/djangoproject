from django.apps import AppConfig


class ChukaezemscrumyConfig(AppConfig):
    name = 'chukaezemscrumy'
